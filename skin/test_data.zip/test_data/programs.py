arr = [12, 3, 4, 15]
ans = sum(arr)
print("sum of array:",ans)